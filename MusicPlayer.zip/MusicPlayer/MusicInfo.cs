﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicPlayer
{
    public class MusicInfo
    {
        public string SongName { get; set; }
        /// <summary>
        /// 时长("yyyy-MM-dd")
        /// </summary>
        public string SongTime { get; set; }

        /// <summary>
        /// 时长（秒）
        /// </summary>
        public int SongTimeLength { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Songer { get; set; }
        /// <summary>
        /// 文件大小
        /// </summary>
        public string SongSize { get; set; }
        public string SongUrl { get; set; }

    }
}
