﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MusicPlayer
{
    public partial class FrmNewMain : Form
    {
        #region 变量声明
        QQMusicAPI qqApi = QQMusicAPI.Instance();
        NeteaseMusicAPI neteaseApi = new NeteaseMusicAPI();
        private SongPlayer _song;
        private AxWMPLib.AxWindowsMediaPlayer myPlayer;
        #endregion
        private MusicType Source
        {
            get
            {
                switch (cmbSource.SelectedValue.ToString())
                {
                    case "1": return MusicType.Netease;
                    case "2": return MusicType.qqMusic;
                    case "3": return MusicType.qqRadio;
                    default:
                        return MusicType.Netease;
                }
            }
        }
        public PlayType playType
        {
            get
            {
                switch (Convert.ToInt32(cmbCycle.SelectedValue))
                {
                    case (int)PlayType.OrderPlay:
                        return PlayType.OrderPlay;
                    case (int)PlayType.ListPlay:
                        return PlayType.ListPlay;
                    case (int)PlayType.SinglePlay:
                        return PlayType.SinglePlay;
                    case (int)PlayType.RandPlay:
                        return PlayType.RandPlay;
                    default:
                        return PlayType.OrderPlay;
                }
            }
        }
        public FrmNewMain()
        {
            InitializeComponent();
            BindSource();
            BindSkin();
            BindControl();
            prevpic.BringToFront();
            play_pause.BringToFront();
            cmbCycle.SelectedIndex = 0;
        }
        private void FrmNewMain_Load(object sender, EventArgs e)
        {
            skinEngine1.SkinFile = Application.StartupPath + @"\skin\DiamondBlue.ssk";
        }

        #region 绑定数据
        private void BindControl()
        {
            myPlayer = new AxWMPLib.AxWindowsMediaPlayer();
            ((System.ComponentModel.ISupportInitialize)(this.myPlayer)).BeginInit();
            myPlayer.Visible = false;
            Controls.Add(myPlayer);
            ((System.ComponentModel.ISupportInitialize)(this.myPlayer)).EndInit();
            _song = new SongPlayer(myPlayer, Source, this);
        }
        private void BindSource()
        {
            //加载播放类型
            var list2 = new List<KeyValue>();
            list2.Add(new KeyValue { Id = "1", Name = "顺序播放" });
            list2.Add(new KeyValue { Id = "2", Name = "列表循环" });
            list2.Add(new KeyValue { Id = "3", Name = "单曲循环" });
            list2.Add(new KeyValue { Id = "4", Name = "随机播放" });
            cmbCycle.DataSource = list2;
            cmbCycle.DisplayMember = "Name";
            cmbCycle.ValueMember = "Id";
            cmbCycle.SelectedIndex = 0;

            var list = new List<KeyValue>();
            list.Add(new KeyValue { Id = "1", Name = "Netease" });
            list.Add(new KeyValue { Id = "2", Name = "QQmusic" });
            list.Add(new KeyValue { Id = "3", Name = "QQ个性电台" });
            cmbSource.DataSource = list;
            cmbSource.DisplayMember = "Name";
            cmbSource.ValueMember = "Id";
            cmbSource.SelectedIndex = 0;
            BindData();
        }
        private void BindData()
        {
            var list = new List<KeyValue>();
            switch (Source)
            {
                case MusicType.Netease:
                    {
                        list.Add(new KeyValue { Id = "19723756", Name = "云音乐飙升榜" });
                        list.Add(new KeyValue { Id = "3778678", Name = "云音乐热歌榜" });
                        list.Add(new KeyValue { Id = "2250011882", Name = "抖音排行榜" });
                        list.Add(new KeyValue { Id = "1978921795", Name = "云音乐电音榜" });
                    }
                    break;
                case MusicType.qqMusic:
                    {
                        var toplist = qqApi.GetTopListCategory();
                        foreach (var item in toplist[0].List)
                        {
                            var id = item.topID.ToString() + "@" + item.update_key;
                            list.Add(new KeyValue { Id = id, Name = item.ListName });
                        }
                    }
                    break;
                case MusicType.qqRadio:
                    {
                        list.Add(new KeyValue { Id = "199", Name = "热歌" });
                        list.Add(new KeyValue { Id = "101", Name = "随心听" });
                        list.Add(new KeyValue { Id = "270", Name = "KTV必点歌" });
                        list.Add(new KeyValue { Id = "167", Name = "网络流行" });
                        list.Add(new KeyValue { Id = "127", Name = "经典" });
                    }
                    break;
                default:
                    break;
            }
            cmbType.DataSource = list;
            cmbType.DisplayMember = "Name";
            cmbType.ValueMember = "Id";
            cmbType.SelectedIndex = 0;
            cmbType.Refresh();
        }
        private void BindSkin()
        {
            var list = new List<KeyValue>();
            list.Add(new KeyValue { Id = "DiamondBlue", Name = "DiamondBlue" });
            list.Add(new KeyValue { Id = "DiamondGreen", Name = "DiamondGreen" });
            list.Add(new KeyValue { Id = "SteelBlack", Name = "SteelBlack" });
            list.Add(new KeyValue { Id = "SteelBlue", Name = "SteelBlue" });
            cmbSkin.DataSource = list;
            cmbSkin.DisplayMember = "Name";
            cmbSkin.ValueMember = "Id";
            cmbSkin.SelectedIndex = 0;
        }
        private void BindList(List<MusicInfo> list)
        {
            lvwData.Items.Clear();
            foreach (var item in list)
            {
                item.SongIndex = list.IndexOf(item);
                ListViewItem li = new ListViewItem();
                li.Tag = item.SongId;
                li.Text = item.SongIndex.ToString();
                li.SubItems.Add(item.SongName);
                li.SubItems.Add(item.Songer);
                li.SubItems.Add(item.SongUrl);
                lvwData.Items.Add(li);
            }
            _song.playList = list;
            _song.currentPlay = null;
            _song.Play();
            BindLyric(_song.currentPlay);
        }
        public void BindLyric(MusicInfo info)
        {
            BindBasic(info);
            lvwLyric.Items.Clear();
            lvwLyric.Columns[0].Text = info.SongName;
            var list = new List<string>();
            switch (Source)
            {
                case MusicType.Netease:
                    {
                        var lyric = neteaseApi.Lyric(info.SongId);
                        foreach (string item in lyric.Lrc.Lyric.Split('\n'))
                        {
                            if (string.IsNullOrEmpty(item)) continue;
                            ListViewItem li = new ListViewItem();
                            string time = item.Length > 5 ? "00:" + item.Substring(1, 5) : "";
                            DateTime.TryParse(time, out DateTime dt);
                            li.Tag = dt;
                            li.Text = item;
                            li.BackColor = Color.FromArgb(199, 237, 204);
                            lvwLyric.Items.Add(li);
                        }
                    }
                    break;
                case MusicType.qqMusic:
                case MusicType.qqRadio:
                    {
                        list = qqApi.GetLyric(info.SongId);
                        foreach (string item in list)
                        {
                            if (string.IsNullOrEmpty(item)) continue;
                            ListViewItem li = new ListViewItem();
                            string time = item.Length > 5 ? "00:" + item.Substring(1, 5) : "";
                            DateTime.TryParse(time, out DateTime dt);
                            li.Tag = dt;
                            li.Text = item;
                            li.BackColor = Color.FromArgb(199, 237, 204);
                            lvwLyric.Items.Add(li);
                        }
                    }
                    break;
                default:
                    break;
            }
        }
        private void BindBasic(MusicInfo info)
        {
            this.Text = info.SongName;
            lblSongName.Text = info.SongName;
            trackBar.Maximum = 1000;
            trackBar.Value = 1;
        }
        private void SetItemLyric(int time)
        {
            foreach (ListViewItem item in lvwLyric.Items)
            {
                item.BackColor = Color.FromArgb(199, 237, 204);
                var tag = item.Tag == null ? "" : item.Tag.ToString();
                DateTime.TryParse(tag, out DateTime dt);
                int len = MusicTool.GetTimeLength(dt);
                if (len <= time)
                {
                    item.BackColor = Color.FromArgb(0, 191, 255);
                    if (len == time)
                    {
                        if (item.Index + 5 < lvwLyric.Items.Count)
                            lvwLyric.EnsureVisible(item.Index + 5);
                        else
                            lvwLyric.EnsureVisible(item.Index);
                    }
                }
            }
        }
        #endregion

        #region 事件
        private void cmbSource_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindData();
        }
        private void cmbSkin_SelectedIndexChanged(object sender, EventArgs e)
        {
            var val = cmbSkin.Text;
            skinEngine1.SkinFile = Application.StartupPath + $@"\skin\{val}.ssk";
        }
        private void btnSearch_Click(object sender, EventArgs e)
        {
            _song.source = Source;
            var list = new List<MusicInfo>();
            switch (Source)
            {
                case MusicType.Netease:
                    {
                        var apires = neteaseApi.Search(txtKeyWord.Text);//传入内容
                        foreach (var song in apires.Result.Songs)//循环读取歌曲信息
                        {
                            list.Add(new MusicInfo
                            {
                                SongId = song.Id.ToString(),
                                SongName = song.Name,
                                Songer = song.Ar[0].Name,
                                SongUrl = neteaseApi.GetSongsUrl(new string[] { song.Id }).Data[0].Url.Replace("m7c.music", "m7.music").Replace("m8c.music", "m8.music")
                            });
                        }
                    }
                    break;
                case MusicType.qqMusic:
                case MusicType.qqRadio:
                    {
                        list = qqApi.Search(txtKeyWord.Text);
                    }
                    break;
                default:
                    break;
            }
            BindList(list);
        }
        private void btnPlay_Click(object sender, EventArgs e)
        {
            var id = cmbType.SelectedValue;
            if (id == null)
                id = "";
            lvwData.Items.Clear();
            _song.source = Source;
            var list = new List<MusicInfo>();
            if (MemoryCacheHelper.GetCache(id.ToString()) != null && Source != MusicType.qqRadio)//电台不获取缓存数据
                list = MemoryCacheHelper.GetCache(id.ToString()) as List<MusicInfo>;
            else
            {
                switch (Source)
                {
                    case MusicType.Netease:
                        list = neteaseApi.GetTopMusic(id.ToString());
                        break;
                    case MusicType.qqMusic:
                        list = qqApi.GetTopList(id.ToString().Split('@')[0], id.ToString().Split('@')[1]);
                        break;
                    case MusicType.qqRadio:
                        list = qqApi.GetSong(id.ToString());
                        break;
                    default:
                        break;
                }
            }
            BindList(list);
            MemoryCacheHelper.SetCache(id.ToString(), list);
        }
        private void lvwData_DoubleClick(object sender, EventArgs e)
        {
            var items = lvwData.SelectedItems;
            if (items == null || items.Count <= 0)
                return;
            _song.play(items[0].Index);
            BindLyric(_song.currentPlay);
        }
        private void mediaplayer_PlayStateChange(object sender, AxWMPLib._WMPOCXEvents_PlayStateChangeEvent e)
        {
            if (e.newState == 1)//停止
            {

            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (_song.playstate == WMPLib.WMPPlayState.wmppsPlaying && trackBar.Value < trackBar.Maximum)
            {
                trackBar.Value += 1;
                lblCurrent.Text = MusicTool.GetTime(trackBar.Value);
                SetItemLyric(trackBar.Value);
            }
            if (_song.playstate == WMPLib.WMPPlayState.wmppsStopped)
            {
                _song.NextMusic();
                BindLyric(_song.currentPlay);
            }
        }
        private void prevpic_Click(object sender, EventArgs e)
        {
            if (_song == null) return;
            _song.PreMusic();
            if (_song.currentPlay == null) return;
            BindLyric(_song.currentPlay);
        }
        private void play_pause_Click(object sender, EventArgs e)
        {
            if (_song == null) return;
            if (_song.playstate == WMPLib.WMPPlayState.wmppsPaused)//暂停状态
            {
                _song.Play();
                timer1.Enabled = true;
                play_pause.Image = Image.FromFile(Application.StartupPath + "\\img\\pause.png");
            }
            else
            {
                _song.Pause();
                timer1.Enabled = false;
                play_pause.Image = Image.FromFile(Application.StartupPath + "\\img\\play.png");
            }
        }
        private void nextpic_Click(object sender, EventArgs e)
        {
            if (_song == null) return;
            _song.NextMusic();
            if (_song.currentPlay == null) return;
            BindLyric(_song.currentPlay);
        }
        private void trackBar_Scroll(object sender, EventArgs e)
        {
            if (_song.playstate == WMPLib.WMPPlayState.wmppsPlaying)
            {
                lblCurrent.Text = MusicTool.GetTime(trackBar.Value);
                _song.myPlayer.Ctlcontrols.currentPosition = trackBar.Value;
                SetItemLyric(trackBar.Value);
            }
        }
        private void UpVoice_ValueChanged(object sender, EventArgs e)
        {
            _song.Volice((int)UpVoice.Value);
        }
        private void DownFileTool_Click(object sender, EventArgs e)
        {
            var items = lvwData.SelectedItems;
            if (items == null || items.Count <= 0)
                return;
            var filename = items[0].Text + ".mp3";
            var media = _song.myPlayer.currentPlaylist.Item[items[0].Index];
            var url = media.sourceURL;
            var thread = new System.Threading.Thread(DownFiles);
            var obj = new object[] { filename, url };
            thread.Start(obj);
        }
        private void DownFiles(object obj)
        {
            var objs = obj as object[];
            var filename = objs[0].ToString();
            var url = objs[1].ToString();
            this.Invoke(new Action(() =>
            {
                var file = new SaveFileDialog();
                file.Filter = "媒体文件|*.mp3;*.wav;*.wma;*.avi;*.mpg;*.asf;*.wmv;*.mp4";
                file.FileName = filename;
                file.RestoreDirectory = true;
                if (file.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        MusicTool.DownFile(url, file.FileName);
                        MessageBox.Show("下载成功！");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("下载文件失败！" + ex.Message);
                    }
                }
            }));

        }
        private void lvwData_MouseMove(object sender, MouseEventArgs e)
        {
            ListViewItem item = this.lvwData.GetItemAt(e.X, e.Y);
            if (item != null)
            {
                string text = $"{item.SubItems[1].Text} - {item.SubItems[2].Text}";
                toolTip1.Show(text, lvwData, new Point(e.X + 15, e.Y + 15), 1000);
                toolTip1.Active = true;
            }
            else
                toolTip1.Active = false;
        }
        private void lvwLyric_MouseMove(object sender, MouseEventArgs e)
        {
            ListViewItem item = this.lvwLyric.GetItemAt(e.X, e.Y);
            if (item != null)
            {
                toolTip1.Show(item.Text, lvwLyric, new Point(e.X + 15, e.Y + 15), 1000);
                toolTip1.Active = true;
            }
            else
                toolTip1.Active = false;
        }
        private void lblSongName_MouseMove(object sender, MouseEventArgs e)
        {
            toolTip1.Show(lblSongName.Text, lblSongName, new Point(e.X + 15, e.Y + 15), 1000);
            toolTip1.Active = true;
        }
        private void trackBar_MouseMove(object sender, MouseEventArgs e)
        {
            toolTip1.Active = false;
        }
        private void FrmNewMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("是否确认退出程序？", "退出", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                // 关闭所有的线程
                this.Dispose();
                this.Close();
                notifyIcon1.Dispose();
            }
            else
            {
                e.Cancel = true;
            }
        }
        private void FrmNewMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            //释放托盘图标，否则会导致堆积
            notifyIcon1.Dispose();
        }
        private void FrmNewMain_SizeChanged(object sender, EventArgs e)
        {
            //判断是否选择的是最小化按钮
            if (WindowState == FormWindowState.Minimized)
            {
                //隐藏任务栏区图标
                //this.ShowInTaskbar = false;
                //图标显示在托盘区
                //notifyIcon1.Visible = true;
            }
        }
        private void notifyIcon1_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                //
                //this.Activate();
                this.notifyIcon1.Visible = false;
                this.ShowInTaskbar = true;
                this.WindowState = FormWindowState.Normal;
            }
        }
        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (WindowState == FormWindowState.Minimized)
            {
                //还原窗体显示    
                WindowState = FormWindowState.Normal;
                //激活窗体并给予它焦点
                //this.Activate();
                //任务栏区显示图标
                this.ShowInTaskbar = true;
                //托盘区图标隐藏
                notifyIcon1.Visible = false;
            }
        }
        #endregion
    }

    public class SongPlayer
    {
        #region 属性
        QQMusicAPI qqApi = QQMusicAPI.Instance();
        NeteaseMusicAPI neteaseApi = new NeteaseMusicAPI();
        public MusicType source;
        private FrmNewMain frmNewMain;
        public AxWMPLib.AxWindowsMediaPlayer myPlayer;
        public List<MusicInfo> playList { get; set; } = new List<MusicInfo>();
        public MusicInfo currentPlay { get; set; }
        public WMPLib.WMPPlayState playstate
        {
            get
            {
                return myPlayer.playState;
            }
        }
        #endregion
        public SongPlayer(AxWMPLib.AxWindowsMediaPlayer player, MusicType type, FrmNewMain frm)
        {
            frmNewMain = frm;
            source = type;
            myPlayer = player;
            //myPlayer = new AxWMPLib.AxWindowsMediaPlayer();
            myPlayer.settings.volume = 60;
            myPlayer.PlayStateChange += MyPlayer_PlayStateChange;
        }
        private void MyPlayer_PlayStateChange(object sender, AxWMPLib._WMPOCXEvents_PlayStateChangeEvent e)
        {
            if (e.newState == 8)//停止状态
            {
                NextMusic();
            }
            else if (e.newState == 10)//准备就绪
                myPlayer.Ctlcontrols.play();
            else if (e.newState == 3 && myPlayer.currentMedia != null)
            {
                var time = myPlayer.currentMedia.duration;
                frmNewMain.trackBar.Value = Convert.ToInt32(myPlayer.Ctlcontrols.currentPosition);
                frmNewMain.trackBar.Maximum = (int)time;
                frmNewMain.lblTotal.Text = MusicTool.GetTime((int)time);
            }
        }
        public void NextMusic()
        {
            if (playList.Count <= 0) return;
            if (currentPlay == null) currentPlay = playList[0];
            switch (frmNewMain.playType)
            {
                case PlayType.OrderPlay:
                    if (currentPlay.SongIndex + 1 < playList.Count)
                    {
                        currentPlay = playList[currentPlay.SongIndex + 1];
                        play(currentPlay.SongIndex);
                    }
                    break;
                case PlayType.ListPlay:
                    {
                        if (currentPlay == null || currentPlay.SongIndex + 1 >= playList.Count)
                            currentPlay = playList[0];
                        else
                            currentPlay = playList[currentPlay.SongIndex + 1];
                        play(currentPlay.SongIndex);
                    }
                    break;
                case PlayType.SinglePlay:
                    play(currentPlay.SongIndex);
                    break;
                case PlayType.RandPlay:
                    {
                        Random random = new Random();
                        var ran = random.Next(0, playList.Count - 1);
                        currentPlay = playList[ran];
                        play(currentPlay.SongIndex);
                    }
                    break;
                default:
                    break;
            }
        }
        public void PreMusic()
        {
            if (playList.Count <= 0) return;
            if (currentPlay == null || currentPlay.SongIndex - 1 < 0)
                currentPlay = playList[playList.Count - 1];
            else
                currentPlay = playList[currentPlay.SongIndex - 1];
            play(currentPlay.SongIndex);
        }
        public void play(int num)
        {
            currentPlay = playList[num];
            if (num - 1 > playList.Count)
                currentPlay = playList[num];
            switch (source)
            {
                case MusicType.Netease:
                    {
                        var url = neteaseApi.GetSongsUrl(new string[] { currentPlay.SongId }).Data[0].Url;
                        currentPlay.SongUrl = string.IsNullOrEmpty(url) ? "https://music.163.com/song/media/outer/url?id=" + currentPlay.SongId + ".mp3" : url.Replace("m7c.music", "m7.music").Replace("m8c.music", "m8.music");
                    }
                    break;
                case MusicType.qqRadio:
                case MusicType.qqMusic:
                    currentPlay.SongUrl = qqApi.GetSongUrl(currentPlay.SongId);
                    break;
                default: return;
            }
            myPlayer.URL = currentPlay.SongUrl;
            frmNewMain.lblSongName.Text = currentPlay.SongName;
            frmNewMain.notifyIcon1.Text = currentPlay.SongName;
            frmNewMain.BindLyric(currentPlay);
            SetListviewColor(currentPlay.SongIndex);
        }
        public void Play()
        {
            if (playList.Count <= 0) return;
            if (currentPlay == null)
            {
                currentPlay = playList[0];
                play(currentPlay.SongIndex);
            }
            else
                myPlayer.Ctlcontrols.play();
        }
        public void Pause()
        {
            myPlayer.Ctlcontrols.pause();
        }
        public void Volice(int num = 60)
        {
            if (num < 1 || num > 100) num = 60;
            myPlayer.settings.volume = num;
        }
        private void SetListviewColor(int index)
        {
            foreach (ListViewItem item in frmNewMain.lvwData.Items)
            {
                item.BackColor = Color.FromArgb(199, 237, 204);
                if (item.Index == index)
                {
                    item.BackColor = Color.FromArgb(0, 191, 255);
                    if (item.Index + 5 < frmNewMain.lvwData.Items.Count)
                        frmNewMain.lvwData.EnsureVisible(index + 5);
                    else
                        frmNewMain.lvwData.EnsureVisible(index);
                }
            }
        }
    }
}
