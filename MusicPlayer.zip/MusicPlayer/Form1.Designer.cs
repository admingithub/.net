﻿namespace MusicPlayer
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lvwData = new System.Windows.Forms.ListView();
            this.SongName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblSongName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblCurrent = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.musicProgress = new System.Windows.Forms.ProgressBar();
            this.cmbType = new System.Windows.Forms.ComboBox();
            this.nextprev = new System.Windows.Forms.PictureBox();
            this.prevpic = new System.Windows.Forms.PictureBox();
            this.play_pause = new System.Windows.Forms.PictureBox();
            this.mediaplayer = new AxWMPLib.AxWindowsMediaPlayer();
            this.btnOpen = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nextprev)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prevpic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.play_pause)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mediaplayer)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.Controls.Add(this.lvwData);
            this.panel1.Location = new System.Drawing.Point(12, 43);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 333);
            this.panel1.TabIndex = 0;
            // 
            // lvwData
            // 
            this.lvwData.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.lvwData.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.SongName});
            this.lvwData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvwData.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lvwData.FullRowSelect = true;
            this.lvwData.GridLines = true;
            this.lvwData.Location = new System.Drawing.Point(0, 0);
            this.lvwData.MultiSelect = false;
            this.lvwData.Name = "lvwData";
            this.lvwData.Size = new System.Drawing.Size(200, 333);
            this.lvwData.TabIndex = 0;
            this.lvwData.UseCompatibleStateImageBehavior = false;
            this.lvwData.View = System.Windows.Forms.View.Details;
            this.lvwData.DoubleClick += new System.EventHandler(this.lvwData_DoubleClick);
            // 
            // SongName
            // 
            this.SongName.Text = "歌曲";
            this.SongName.Width = 195;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.lblSongName);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.lblCurrent);
            this.panel2.Controls.Add(this.lblTotal);
            this.panel2.Controls.Add(this.musicProgress);
            this.panel2.Controls.Add(this.cmbType);
            this.panel2.Controls.Add(this.nextprev);
            this.panel2.Controls.Add(this.prevpic);
            this.panel2.Controls.Add(this.play_pause);
            this.panel2.Location = new System.Drawing.Point(12, 374);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(785, 86);
            this.panel2.TabIndex = 1;
            // 
            // lblSongName
            // 
            this.lblSongName.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblSongName.AutoSize = true;
            this.lblSongName.Location = new System.Drawing.Point(50, 38);
            this.lblSongName.Name = "lblSongName";
            this.lblSongName.Size = new System.Drawing.Size(17, 12);
            this.lblSongName.TabIndex = 8;
            this.lblSongName.Text = "无";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(717, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(11, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "/";
            // 
            // lblCurrent
            // 
            this.lblCurrent.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblCurrent.AutoSize = true;
            this.lblCurrent.Location = new System.Drawing.Point(655, 17);
            this.lblCurrent.Name = "lblCurrent";
            this.lblCurrent.Size = new System.Drawing.Size(53, 12);
            this.lblCurrent.TabIndex = 6;
            this.lblCurrent.Text = "00:00:00";
            // 
            // lblTotal
            // 
            this.lblTotal.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(731, 17);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(53, 12);
            this.lblTotal.TabIndex = 5;
            this.lblTotal.Text = "00:00:00";
            // 
            // musicProgress
            // 
            this.musicProgress.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.musicProgress.Location = new System.Drawing.Point(3, 3);
            this.musicProgress.Maximum = 0;
            this.musicProgress.Name = "musicProgress";
            this.musicProgress.Size = new System.Drawing.Size(779, 10);
            this.musicProgress.TabIndex = 4;
            // 
            // cmbType
            // 
            this.cmbType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.cmbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbType.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmbType.FormattingEnabled = true;
            this.cmbType.Items.AddRange(new object[] {
            "顺序播放",
            "列表循环",
            "单曲循环",
            "随机播放"});
            this.cmbType.Location = new System.Drawing.Point(452, 38);
            this.cmbType.Name = "cmbType";
            this.cmbType.Size = new System.Drawing.Size(121, 27);
            this.cmbType.TabIndex = 3;
            // 
            // nextprev
            // 
            this.nextprev.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.nextprev.Cursor = System.Windows.Forms.Cursors.Hand;
            this.nextprev.Image = ((System.Drawing.Image)(resources.GetObject("nextprev.Image")));
            this.nextprev.Location = new System.Drawing.Point(370, 24);
            this.nextprev.Name = "nextprev";
            this.nextprev.Size = new System.Drawing.Size(46, 48);
            this.nextprev.TabIndex = 2;
            this.nextprev.TabStop = false;
            this.nextprev.Click += new System.EventHandler(this.nextprev_Click);
            // 
            // prevpic
            // 
            this.prevpic.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.prevpic.Cursor = System.Windows.Forms.Cursors.Hand;
            this.prevpic.Image = ((System.Drawing.Image)(resources.GetObject("prevpic.Image")));
            this.prevpic.Location = new System.Drawing.Point(206, 24);
            this.prevpic.Name = "prevpic";
            this.prevpic.Size = new System.Drawing.Size(49, 48);
            this.prevpic.TabIndex = 1;
            this.prevpic.TabStop = false;
            this.prevpic.Click += new System.EventHandler(this.prevpic_Click);
            // 
            // play_pause
            // 
            this.play_pause.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.play_pause.Cursor = System.Windows.Forms.Cursors.Hand;
            this.play_pause.Image = ((System.Drawing.Image)(resources.GetObject("play_pause.Image")));
            this.play_pause.Location = new System.Drawing.Point(290, 24);
            this.play_pause.Name = "play_pause";
            this.play_pause.Size = new System.Drawing.Size(49, 48);
            this.play_pause.TabIndex = 0;
            this.play_pause.TabStop = false;
            this.play_pause.Click += new System.EventHandler(this.play_pause_Click);
            // 
            // mediaplayer
            // 
            this.mediaplayer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mediaplayer.Enabled = true;
            this.mediaplayer.Location = new System.Drawing.Point(5, 3);
            this.mediaplayer.Name = "mediaplayer";
            this.mediaplayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("mediaplayer.OcxState")));
            this.mediaplayer.Size = new System.Drawing.Size(576, 330);
            this.mediaplayer.TabIndex = 0;
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(345, 11);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(75, 23);
            this.btnOpen.TabIndex = 2;
            this.btnOpen.Text = "选择文件";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.mediaplayer);
            this.panel3.Location = new System.Drawing.Point(213, 43);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(584, 333);
            this.panel3.TabIndex = 3;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.Click += new System.EventHandler(this.notifyIcon1_Click);
            this.notifyIcon1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseDoubleClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 461);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(800, 500);
            this.Name = "Form1";
            this.Text = "本地播放器";
            this.Activated += new System.EventHandler(this.Form1_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.SizeChanged += new System.EventHandler(this.Form1_SizeChanged);
            this.Leave += new System.EventHandler(this.Form1_Leave);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nextprev)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prevpic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.play_pause)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mediaplayer)).EndInit();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ListView lvwData;
        private System.Windows.Forms.Button btnOpen;
        private AxWMPLib.AxWindowsMediaPlayer mediaplayer;
        private System.Windows.Forms.ColumnHeader SongName;
        private System.Windows.Forms.PictureBox play_pause;
        private System.Windows.Forms.PictureBox nextprev;
        private System.Windows.Forms.PictureBox prevpic;
        private System.Windows.Forms.ComboBox cmbType;
        private System.Windows.Forms.ProgressBar musicProgress;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblCurrent;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.Label lblSongName;
    }
}

