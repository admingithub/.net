﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicPlayer
{
    public class MusicTool
    {
        public static int GetTimeLength(DateTime time)
        {
            var hour = time.Hour * 60 * 60;
            var min = time.Minute * 60;
            return hour + min + time.Second;
        }
        public static DateTime GetTime(int timeSecond)
        {
            string hour = "00";
            int m = timeSecond / 60;
            if (timeSecond / 60 > 60)
            {
                int h = timeSecond / 60 / 60;
                hour = h < 10 ? "0" + h : h.ToString();
                m = m % 60;
            }
            string min = m < 10 ? "0" + m : m.ToString();
            int s = timeSecond % 60;
            string second = s < 10 ? "0" + s : s.ToString();
            return Convert.ToDateTime($"{hour}:{min}:{second}");
        }
    }
}
