﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Shell32;
using System.Text.RegularExpressions;
using System.IO;

namespace MusicPlayer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            cmbType.SelectedIndex = 0;
            myplayer = new Player(mediaplayer);
        }
        private static Player myplayer=new Player();
        private static List<MusicInfo> musicList;
        private void btnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.Multiselect = true;
            fileDialog.DefaultExt = "*.mp3|*.mp4";
            fileDialog.ShowDialog();
            if (fileDialog.FileNames.Count() <= 0)
                return;
            var list = new List<MusicInfo>();
            lvwData.Items.Clear();
            myplayer = new Player(mediaplayer);
            musicList = new List<MusicInfo>();
            foreach (var item in fileDialog.FileNames)
            {
                ListViewItem li = new ListViewItem();
                li.Tag = Guid.NewGuid().ToString();
                var songName = item.Substring(item.LastIndexOf('\\') + 1).Split('.')[0];
                li.Text = songName;
                li.SubItems.Add(item);
                lvwData.Items.Add(li);
                myplayer.AddFile(item);
                var media = mediaplayer.newMedia(item);
                mediaplayer.currentPlaylist.appendItem(media);
                musicList.Add(GetMusicInfo(item));
            }
            if (lvwData.Items.Count <= 0)
                return;
            myplayer.play(0);
            SetListviewColor(lvwData.Items[0]);
            InitProgress(musicList[0]);
        }

        private void lvwData_DoubleClick(object sender, EventArgs e)
        {
            var items = lvwData.SelectedItems;
            if (items == null || items.Count <= 0)
                return;
            SetListviewColor(items[0]);
            myplayer.play(items[0].Index);
            InitProgress(musicList[items[0].Index]);
        }

        #region 按键事件
        private void play_pause_Click(object sender, EventArgs e)
        {
            switch (myplayer.playstate)
            {
                case WMPLib.WMPPlayState.wmppsUndefined:
                    break;
                case WMPLib.WMPPlayState.wmppsStopped:
                case WMPLib.WMPPlayState.wmppsPaused:
                    myplayer.Play();
                    timer1.Enabled = true;
                    play_pause.Image = Image.FromFile(Application.StartupPath + "\\img\\pause.png");
                    break;
                case WMPLib.WMPPlayState.wmppsPlaying:
                    myplayer.Pause();
                    timer1.Enabled = false;
                    play_pause.Image = Image.FromFile(Application.StartupPath + "\\img\\play.png");
                    //play_pause.ImageLocation = "img/play.png";
                    break;
                case WMPLib.WMPPlayState.wmppsScanForward:
                    break;
                case WMPLib.WMPPlayState.wmppsScanReverse:
                    break;
                case WMPLib.WMPPlayState.wmppsBuffering:
                    break;
                case WMPLib.WMPPlayState.wmppsWaiting:
                    break;
                case WMPLib.WMPPlayState.wmppsMediaEnded:
                    break;
                case WMPLib.WMPPlayState.wmppsTransitioning:
                    break;
                case WMPLib.WMPPlayState.wmppsReady:
                    break;
                case WMPLib.WMPPlayState.wmppsReconnecting:
                    break;
                case WMPLib.WMPPlayState.wmppsLast:
                    break;
                default:
                    break;
            }
        }

        private void prevpic_Click(object sender, EventArgs e)
        {
            var index = myplayer.PrevPlay(cmbType.SelectedIndex);
            myplayer.play(index);
            InitProgress(musicList[index]);
            SetListviewColor(lvwData.Items[index]);
        }

        private void nextprev_Click(object sender, EventArgs e)
        {
            var index = myplayer.NextPlay(cmbType.SelectedIndex);
            myplayer.play(index);
            InitProgress(musicList[index]);
            SetListviewColor(lvwData.Items[index]);
        }
        #endregion

        #region 设置属性

        private MusicInfo GetMusicInfo(string songPath)
        {
            string dirName = Path.GetDirectoryName(songPath);
            var SongName = Path.GetFileName(songPath);//获得歌曲名称
            FileInfo fInfo = new FileInfo(songPath);
            var sh = new ShellClass();
            Folder dir = sh.NameSpace(dirName);
            FolderItem item = dir.ParseName(SongName);
            var song = dir.GetDetailsOf(item, -1);
            var songsize = song.Split('\n')[1].Split(':')[1];
            var songtime = song.Substring(song.IndexOf("时长") + 3).Trim();
            return new MusicInfo { SongName = SongName.Split('.')[0], SongSize = songsize, SongTime = songtime, SongTimeLength = MusicTool.GetTimeLength(Convert.ToDateTime(songtime)), SongUrl = songPath };
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            int total = MusicTool.GetTimeLength(Convert.ToDateTime(lblTotal.Text));
            if (musicProgress.Value >= total)
                nextprev_Click(sender, e);
            else
            {
                musicProgress.Value += 1;
                lblCurrent.Text = MusicTool.GetTime(musicProgress.Value).ToString("T");
            }
        }
        private void InitProgress(MusicInfo info)
        {
            musicProgress.Value = 0;
            musicProgress.Maximum = info.SongTimeLength;
            lblTotal.Text = info.SongTime;
            timer1.Enabled = true;
            lblSongName.Text = info.SongName;
        }
        private void SetListviewColor(ListViewItem li)
        {
            foreach (ListViewItem item in lvwData.Items)
            {
                item.BackColor = ColorTranslator.FromHtml("#C7EDCC"); ;
                if (item.Index == li.Index)
                    item.BackColor = ColorTranslator.FromHtml("#84A0C4");
            }
        }

        #endregion

        #region 窗体改变事件
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("是否确认退出程序？", "退出", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                // 关闭所有的线程
                this.Dispose();
                this.Close();
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void Form1_SizeChanged(object sender, EventArgs e)
        {
            //判断是否选择的是最小化按钮
            if (WindowState == FormWindowState.Minimized)
            {
                //隐藏任务栏区图标
                this.ShowInTaskbar = false;
                //图标显示在托盘区
                notifyIcon1.Visible = true;
            }
        }

        private void notifyIcon1_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.WindowState = FormWindowState.Maximized;
                this.Activate();
                this.notifyIcon1.Visible = false;
                this.ShowInTaskbar = true;
            }
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (WindowState == FormWindowState.Minimized)
            {
                //还原窗体显示    
                WindowState = FormWindowState.Normal;
                //激活窗体并给予它焦点
                this.Activate();
                //任务栏区显示图标
                this.ShowInTaskbar = true;
                //托盘区图标隐藏
                notifyIcon1.Visible = false;
            }
        }
        #endregion

        #region 全局快捷键
        private void Form1_Activated(object sender, EventArgs e)
        {
            //注册热键ALT+→，Id号为100。HotKey.KeyModifiers.ALT也可以直接使用数字4来表示。
            HotKey.RegisterHotKey(Handle, 100, HotKey.KeyModifiers.Alt, Keys.Right);
            //注册热键ALT+←，Id号为101。HotKey.KeyModifiers.Alt也可以直接使用数字2来表示。
            HotKey.RegisterHotKey(Handle, 101, HotKey.KeyModifiers.Alt, Keys.Left);
            //注册热键Alt+↑，Id号为102。HotKey.KeyModifiers.Alt也可以直接使用数字1来表示。
            HotKey.RegisterHotKey(Handle, 102, HotKey.KeyModifiers.Alt, Keys.Up);
            //注册热键Alt+↓，Id号为103。HotKey.KeyModifiers.Alt也可以直接使用数字1来表示。
            HotKey.RegisterHotKey(Handle, 103, HotKey.KeyModifiers.Alt, Keys.Down);
        }
        //在FormA的Leave事件中注销热键。
        private void Form1_Leave(object sender, EventArgs e)
        {
            //注销Id号为100的热键设定
            HotKey.UnregisterHotKey(Handle, 100);
            //注销Id号为101的热键设定
            HotKey.UnregisterHotKey(Handle, 101);
            //注销Id号为102的热键设定
            HotKey.UnregisterHotKey(Handle, 102);
            //注销Id号为103的热键设定
            HotKey.UnregisterHotKey(Handle, 103);
        }
        /// <summary>
        /// 重载FromA中的WndProc函数
        /// </summary>
        /// <param name="m"></param>
        protected override void WndProc(ref Message m)
        {
            const int WM_HOTKEY = 0x0312;
            //按快捷键 
            switch (m.Msg)
            {
                case WM_HOTKEY:
                    switch (m.WParam.ToInt32())
                    {
                        case 100:    //按下的是ALT+→
                            nextprev_Click(null, null);
                            break;
                        case 101:    //按下的是ALT+←
                            prevpic_Click(null, null);
                            break;
                        case 102:    //按下的是Alt+↑
                            myplayer.UpVoice();
                            break;
                        case 103:   //按下的是Alt+↓
                            myplayer.DownVoice();
                            break;
                    }
                    break;
            }
            base.WndProc(ref m);
        }
        #endregion
    }
    public class Player
    {
        private AxWMPLib.AxWindowsMediaPlayer myPlayer;
        private string[] playList;
        private int numOfMusic;
        private int currentPlay;
        public int index = 0;

        public int NumOfMusic
        {
            get
            {
                return numOfMusic;
            }
        }

        public WMPLib.WMPPlayState playstate
        {
            get
            {
                return myPlayer.playState;
            }
        }

        public string PlayList(int num)
        {
            return playList[num];
        }
        public Player()
        {
            myPlayer = new AxWMPLib.AxWindowsMediaPlayer();
        }
        public Player(AxWMPLib.AxWindowsMediaPlayer mediaPlayer)
        {
            myPlayer = mediaPlayer;
            playList = new string[1000];
            numOfMusic = 0;
        }
        private void InitProgress(ProgressBar progress)
        {
            progress.Value = 0;
        }

        public void AddFile(string path)
        {
            if (numOfMusic < 1000)
            {
                playList[numOfMusic] = path;
                numOfMusic++;
            }
        }

        public void DelFile(int selectNum)
        {
            for (int i = selectNum; i <= numOfMusic - 1; i++)
            {
                playList[i] = playList[i + 1];
            }
            numOfMusic--;
        }

        public void play(int selectNum)
        {
            myPlayer.URL = playList[selectNum];
            currentPlay = selectNum;
            index = selectNum;
        }
        public void Play()
        {
            myPlayer.Ctlcontrols.play();
        }
        public void Pause()
        {
            myPlayer.Ctlcontrols.pause();
        }
        public void UpVoice()
        {
            myPlayer.settings.volume += 2;
        }
        public void DownVoice()
        {
            myPlayer.settings.volume -= 2;
        }
        public int PrevPlay(int type)
        {
            /* type = 0 顺序

          　　type = 1 重复播放全部
          　　type = 2 重复播放一首
          　　type = 3 随机播放

          　　*/

            switch (type)
            {
                case 0:
                case 1:
                    currentPlay--;
                    if (currentPlay == 0) return currentPlay;
                    else if (currentPlay < 0) return numOfMusic - 1;
                    else return currentPlay;
                case 2:
                    return currentPlay;
                case 3:
                    Random rdm = new Random(unchecked((int)DateTime.Now.Ticks));
                    currentPlay = rdm.Next() % numOfMusic;
                    if (currentPlay == 0) return numOfMusic;
                    else return currentPlay;
                default:
                    return 0;
            }
        }
        public int NextPlay(int type)
        {
            /* type = 0 顺序

          　　type = 1 重复播放全部
          　　type = 2 重复播放一首
          　　type = 3 随机播放

          　　*/
            switch (type)
            {
                case 0:
                    currentPlay++;
                    if (currentPlay >= numOfMusic) return 0;
                    else return currentPlay;
                case 1:
                    currentPlay++;
                    if (currentPlay >= numOfMusic) return 1;
                    else return currentPlay;
                case 2:
                    return currentPlay;
                case 3:
                    Random rdm = new Random(unchecked((int)DateTime.Now.Ticks));
                    currentPlay = rdm.Next() % numOfMusic;
                    if (currentPlay == 0) return numOfMusic;
                    else return currentPlay;
                default:
                    return 0;
            }
        }
    }

}
