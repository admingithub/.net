﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicPlayer
{
    public class QQMusic
    {

    }
    public class TopList
    {
        public string GroupID { get; set; }
        public string GroupName { get; set; }
        public List<TopListCategory> List { get; set; }
        public int Type { get; set; }
    }
    public class TopListCategory
    {
        public string ListName { get; set; }
        public int topID { get; set; }
        public string update_key { get; set; }
    }

}
