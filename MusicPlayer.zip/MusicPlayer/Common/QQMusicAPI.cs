﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace MusicPlayer
{
    public class QQMusicAPI
    {
        private static QQMusicAPI qQMusic;
        public static QQMusicAPI Instance()
        {
            if (qQMusic == null)
                qQMusic = new QQMusicAPI();
            return qQMusic;
        }
        /// <summary>
        /// 获取电台音乐
        /// </summary>
        /// <param name="id">电台Id</param>
        /// <returns></returns>
        public List<MusicInfo> GetSong(string id)
        {
            var url = $"https://u.y.qq.com/cgi-bin/musicu.fcg?-=getradiosonglist4871281737878832&g_tk=5381&loginUin=0&hostUin=0&format=json&inCharset=utf8&outCharset=utf-8&notice=0&platform=yqq.json&needNewCode=0&data=%7B%22songlist%22%3A%7B%22module%22%3A%22pf.radiosvr%22%2C%22method%22%3A%22GetRadiosonglist%22%2C%22param%22%3A%7B%22id%22%3A{id}%2C%22firstplay%22%3A1%2C%22num%22%3A10%7D%7D%2C%22radiolist%22%3A%7B%22module%22%3A%22pf.radiosvr%22%2C%22method%22%3A%22GetRadiolist%22%2C%22param%22%3A%7B%22ct%22%3A%2224%22%7D%7D%2C%22comm%22%3A%7B%22ct%22%3A%2224%22%7D%7D";
            WebClient client = new WebClient();
            client.Encoding = Encoding.UTF8;
            var result = client.DownloadString(url);
            var obj = MusicTool.DeserializeStringToDictionary<object, object>(result);
            var songlist = MusicTool.DeserializeStringToDictionary<object, object>(obj["songlist"].ToString());
            var data = MusicTool.DeserializeStringToDictionary<object, object>(songlist["data"].ToString());
            var track_list = data["track_list"] as Newtonsoft.Json.Linq.JArray;
            List<MusicInfo> list = new List<MusicInfo>();
            foreach (dynamic item in track_list.Children())
            {
                //var songurl = GetSongUrl(item.mid.ToString());
                list.Add(new MusicInfo
                {
                    SongId = item.mid.ToString(),
                    SongName = item.title,
                    Songer = GetSonger(item.singer),
                    SongUrl =null// songurl
                });
            }
            return list;
        }
        /// <summary>
        /// 搜索
        /// </summary>
        /// <param name="keyword">关键字</param>
        /// <returns></returns>
        public List<MusicInfo> Search(string keyword)
        {
            Encoding utf8 = Encoding.UTF8;
            //首先用utf-8进行解码                    
            string code = System.Web.HttpUtility.UrlEncode(keyword, utf8);
            var url = $"https://c.y.qq.com/soso/fcgi-bin/client_search_cp?ct=24&qqmusic_ver=1298&new_json=1&remoteplace=txt.yqq.center&searchid=37728264098360808&t=0&aggr=1&cr=1&catZhida=1&lossless=0&flag_qc=0&p=1&n=20&w={code.ToUpper()}&g_tk=5381&loginUin=0&hostUin=0&format=json&inCharset=utf8&outCharset=utf-8&notice=0&platform=yqq.json&needNewCode=0";
            WebClient client = new WebClient();
            client.Encoding = Encoding.UTF8;
            var result = client.DownloadString(url);
            var obj = MusicTool.DeserializeStringToDictionary<object, object>(result);
            var data = MusicTool.DeserializeStringToDictionary<object, object>(obj["data"].ToString());
            var song = MusicTool.DeserializeStringToDictionary<object, object>(data["song"].ToString());
            var songlist = song["list"] as Newtonsoft.Json.Linq.JArray;
            var list = new List<MusicInfo>();
            foreach (dynamic item in songlist.Children())
            {
                var songurl = GetSongUrl(item.mid.ToString());
                list.Add(new MusicInfo
                {
                    SongId = item.mid.ToString(),
                    SongName = item.title,
                    Songer = GetSonger(item.singer),
                    SongUrl = songurl
                });
            }
            return list;
        }
        /// <summary>
        /// 获取音乐地址
        /// </summary>
        /// <param name="mid">音乐Id</param>
        /// <returns></returns>
        public string GetSongUrl(string mid)
        {
            var url = $"https://u.y.qq.com/cgi-bin/musicu.fcg?-=getplaysongvkey7202785251801513&g_tk=5381&loginUin=0&hostUin=0&format=json&inCharset=utf8&outCharset=utf-8&notice=0&platform=yqq.json&needNewCode=0&data=%7B%22req%22%3A%7B%22module%22%3A%22CDN.SrfCdnDispatchServer%22%2C%22method%22%3A%22GetCdnDispatch%22%2C%22param%22%3A%7B%22guid%22%3A%229756534816%22%2C%22calltype%22%3A0%2C%22userip%22%3A%22%22%7D%7D%2C%22req_0%22%3A%7B%22module%22%3A%22vkey.GetVkeyServer%22%2C%22method%22%3A%22CgiGetVkey%22%2C%22param%22%3A%7B%22guid%22%3A%226541487400%22%2C%22songmid%22%3A%5B%22{mid}%22%5D%2C%22songtype%22%3A%5B0%5D%2C%22uin%22%3A%220%22%2C%22loginflag%22%3A1%2C%22platform%22%3A%2220%22%7D%7D%2C%22comm%22%3A%7B%22uin%22%3A0%2C%22format%22%3A%22json%22%2C%22ct%22%3A20%2C%22cv%22%3A0%7D%7D";
            WebClient client = new WebClient();
            client.Encoding = Encoding.UTF8;
            var result = client.DownloadString(url);
            var obj = MusicTool.DeserializeStringToDictionary<object, object>(result);
            var songlist = MusicTool.DeserializeStringToDictionary<object, object>(obj["req"].ToString());
            var data = MusicTool.DeserializeStringToDictionary<object, object>(songlist["data"].ToString());
            var ips = data["freeflowsip"] as Newtonsoft.Json.Linq.JArray;
            string purl = string.Empty;
            #region 获取参数
            {
                var req_0 = MusicTool.DeserializeStringToDictionary<object, object>(obj["req_0"].ToString());
                var req_0_data = MusicTool.DeserializeStringToDictionary<object, object>(req_0["data"].ToString());
                var midure = req_0_data["midurlinfo"] as Newtonsoft.Json.Linq.JArray;
                if (midure.Count > 0)
                {
                    var urls = MusicTool.DeserializeStringToDictionary<object, object>(midure[0].ToString());
                    purl = urls["purl"].ToString();
                }
            }
            #endregion
            if (ips.Count > 0 && !string.IsNullOrEmpty(purl))
                return ips[0] + purl;
            return "";
        }
        /// <summary>
        /// 合并音乐人
        /// </summary>
        /// <param name="singer">音乐人集合</param>
        /// <returns></returns>
        private string GetSonger(Newtonsoft.Json.Linq.JArray singer)
        {
            var name = new StringBuilder();
            foreach (dynamic item in singer)
            {
                name.Append(item.name + ",");
            }
            return name.ToString().TrimEnd(',');
        }
        /// <summary>
        /// 获取排行榜歌曲
        /// </summary>
        /// <param name="Id">排行榜Id</param>
        /// <param name="update_key">更新时间key</param>
        /// <returns></returns>
        public List<MusicInfo> GetTopList(string Id, string update_key)
        {
            int pagesize = 100;
            var url = $"https://c.y.qq.com/v8/fcg-bin/fcg_v8_toplist_cp.fcg?tpl=3&page=detail&date={update_key}&topid={Id}&type=top&song_begin=0&song_num={pagesize}&g_tk=5381&loginUin=0&hostUin=0&format=json&inCharset=utf8&outCharset=utf-8&notice=0&platform=yqq.json&needNewCode=0";
            WebClient client = new WebClient();
            client.Encoding = Encoding.UTF8;
            var result = client.DownloadString(url);
            var data = JsonConvert.DeserializeObject<dynamic>(result);
            var track_list = data.songlist as Newtonsoft.Json.Linq.JArray;
            List<MusicInfo> list = new List<MusicInfo>();
            foreach (dynamic item in track_list.Children())
            {
                var songurl = GetSongUrl(item.data.songmid.ToString());
                list.Add(new MusicInfo
                {
                    SongId = item.data.songmid.ToString(),
                    SongName = item.data.songname,
                    Songer = GetSonger(item.data.singer),
                    SongUrl = songurl
                });
            }
            return list;
        }
        /// <summary>
        /// 获取排行榜类别
        /// </summary>
        /// <returns></returns>
        public List<TopList> GetTopListCategory()
        {
            string key = "qqmusic-toplist";
            if (MemoryCacheHelper.GetCache(key) != null)
                return MemoryCacheHelper.GetCache(key) as List<TopList>;
            else
            {
                var url = "https://c.y.qq.com/v8/fcg-bin/fcg_v8_toplist_opt.fcg?page=index&format=html&tpl=macv4&v8debug=1&jsonCallback=jsonCallback";
                WebClient client = new WebClient();
                client.Encoding = Encoding.UTF8;
                var result = client.DownloadString(url);
                result = result.Substring(result.IndexOf('(') + 1);
                result = result.Substring(0, result.LastIndexOf(")"));
                var des = JsonConvert.DeserializeObject<List<TopList>>(result);
                MemoryCacheHelper.SetCache(key, des);
                return des;
            }
        }
        /// <summary>
        /// 获取歌词
        /// </summary>
        /// <param name="songmid">歌曲Id</param>
        /// <returns></returns>
        public List<string> GetLyric(string songmid)
        {
            string key = "qqmusic-lyric-" + songmid;
            if (MemoryCacheHelper.GetCache(key) != null)
                return MemoryCacheHelper.GetCache(key) as List<string>;
            else
            {
                var url = $"https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg?songmid={songmid}&g_tk=5381";
                WebClient client = new WebClient();

                client.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.110 Safari/537.36");
                client.Headers.Add("Accept", "*/*");
                client.Headers.Add("Referer", "https://y.qq.com/portal/player.html");
                client.Headers.Add("Accept-Language", "zh-CN,zh;q=0.8");
                client.Headers.Add("Cookie", "tvfe_boss_uuid=c3db0dcc4d677c60; pac_uid=1_2728578956; qq_slist_autoplay=on; ts_refer=ADTAGh5_playsong; RK=pKOOKi2f1O; pgv_pvi=8927113216; o_cookie=2728578956; pgv_pvid=5107924810; ptui_loginuin=2728578956; ptcz=897c17d7e17ae9009e018ebf3f818355147a3a26c6c67a63ae949e24758baa2d; pt2gguin=o2728578956; pgv_si=s5715204096; qqmusic_fromtag=66; yplayer_open=1; ts_last=y.qq.com/portal/player.html; ts_uid=996779984; yq_index=0");

                client.Headers.Add("Host", "c.y.qq.com");
                var result = client.DownloadString(url);
                result = result.Substring(result.IndexOf('(') + 1);
                result = result.Substring(0, result.LastIndexOf(')'));
                var data = JsonConvert.DeserializeObject<dynamic>(result);
                string lyric = MusicTool.Base64Decode(data.lyric.ToString());
                var list = new List<string>();
                foreach (var item in lyric.Split('\n'))
                {
                    list.Add(item);
                }
                return list;
            }
        }
    }
}
