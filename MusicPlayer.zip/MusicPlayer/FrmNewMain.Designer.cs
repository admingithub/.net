﻿namespace MusicPlayer
{
    partial class FrmNewMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.ColumnHeader SongIndex;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmNewMain));
            System.Windows.Forms.ColumnHeader 歌词;
            this.DownFile = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.DownFileTool = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.skinEngine1 = new Sunisoft.IrisSkin.SkinEngine(((System.ComponentModel.Component)(this)));
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.PanButtom = new System.Windows.Forms.Panel();
            this.panelButtom = new System.Windows.Forms.Panel();
            this.UpVoice = new System.Windows.Forms.NumericUpDown();
            this.lblSongName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblCurrent = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.cmbCycle = new System.Windows.Forms.ComboBox();
            this.nextpic = new System.Windows.Forms.PictureBox();
            this.prevpic = new System.Windows.Forms.PictureBox();
            this.play_pause = new System.Windows.Forms.PictureBox();
            this.trackBar = new System.Windows.Forms.TrackBar();
            this.PanTop = new System.Windows.Forms.Panel();
            this.cmbSkin = new System.Windows.Forms.ComboBox();
            this.cmbSource = new System.Windows.Forms.ComboBox();
            this.cmbType = new System.Windows.Forms.ComboBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtKeyWord = new System.Windows.Forms.TextBox();
            this.btnPlay = new System.Windows.Forms.Button();
            this.PanLeft = new System.Windows.Forms.Panel();
            this.lvwData = new System.Windows.Forms.ListView();
            this.SongName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Songer = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.PanRight = new System.Windows.Forms.Panel();
            this.lvwLyric = new MusicPlayer.ListViewDoubleBuffer();
            SongIndex = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            歌词 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DownFile.SuspendLayout();
            this.PanButtom.SuspendLayout();
            this.panelButtom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UpVoice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nextpic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prevpic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.play_pause)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar)).BeginInit();
            this.PanTop.SuspendLayout();
            this.PanLeft.SuspendLayout();
            this.PanRight.SuspendLayout();
            this.SuspendLayout();
            // 
            // SongIndex
            // 
            SongIndex.Text = "序号";
            SongIndex.Width = 50;
            // 
            // DownFile
            // 
            this.DownFile.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.DownFileTool});
            this.DownFile.Name = "DownFile";
            this.DownFile.Size = new System.Drawing.Size(101, 26);
            // 
            // DownFileTool
            // 
            this.DownFileTool.Name = "DownFileTool";
            this.DownFileTool.Size = new System.Drawing.Size(100, 22);
            this.DownFileTool.Text = "下载";
            this.DownFileTool.Click += new System.EventHandler(this.DownFileTool_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // skinEngine1
            // 
            this.skinEngine1.SerialNumber = "";
            this.skinEngine1.SkinFile = null;
            // 
            // toolTip1
            // 
            this.toolTip1.Active = false;
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "OnlineMusic";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.Click += new System.EventHandler(this.notifyIcon1_Click);
            this.notifyIcon1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseDoubleClick);
            // 
            // PanButtom
            // 
            this.PanButtom.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PanButtom.Controls.Add(this.panelButtom);
            this.PanButtom.Controls.Add(this.trackBar);
            this.PanButtom.Location = new System.Drawing.Point(12, 367);
            this.PanButtom.Name = "PanButtom";
            this.PanButtom.Size = new System.Drawing.Size(819, 94);
            this.PanButtom.TabIndex = 16;
            // 
            // panelButtom
            // 
            this.panelButtom.Controls.Add(this.UpVoice);
            this.panelButtom.Controls.Add(this.lblSongName);
            this.panelButtom.Controls.Add(this.label1);
            this.panelButtom.Controls.Add(this.lblCurrent);
            this.panelButtom.Controls.Add(this.lblTotal);
            this.panelButtom.Controls.Add(this.cmbCycle);
            this.panelButtom.Controls.Add(this.nextpic);
            this.panelButtom.Controls.Add(this.prevpic);
            this.panelButtom.Controls.Add(this.play_pause);
            this.panelButtom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelButtom.Location = new System.Drawing.Point(0, 24);
            this.panelButtom.Name = "panelButtom";
            this.panelButtom.Size = new System.Drawing.Size(819, 70);
            this.panelButtom.TabIndex = 13;
            // 
            // UpVoice
            // 
            this.UpVoice.Location = new System.Drawing.Point(606, 24);
            this.UpVoice.Name = "UpVoice";
            this.UpVoice.Size = new System.Drawing.Size(52, 21);
            this.UpVoice.TabIndex = 10;
            this.UpVoice.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.UpVoice.ValueChanged += new System.EventHandler(this.UpVoice_ValueChanged);
            // 
            // lblSongName
            // 
            this.lblSongName.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblSongName.Location = new System.Drawing.Point(21, 18);
            this.lblSongName.Name = "lblSongName";
            this.lblSongName.Size = new System.Drawing.Size(166, 48);
            this.lblSongName.TabIndex = 8;
            this.lblSongName.Text = "无";
            this.lblSongName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSongName.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lblSongName_MouseMove);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(751, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(11, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "/";
            // 
            // lblCurrent
            // 
            this.lblCurrent.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblCurrent.AutoSize = true;
            this.lblCurrent.Location = new System.Drawing.Point(689, 9);
            this.lblCurrent.Name = "lblCurrent";
            this.lblCurrent.Size = new System.Drawing.Size(53, 12);
            this.lblCurrent.TabIndex = 6;
            this.lblCurrent.Text = "00:00:00";
            // 
            // lblTotal
            // 
            this.lblTotal.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(765, 9);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(53, 12);
            this.lblTotal.TabIndex = 5;
            this.lblTotal.Text = "00:00:00";
            // 
            // cmbCycle
            // 
            this.cmbCycle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.cmbCycle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCycle.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmbCycle.FormattingEnabled = true;
            this.cmbCycle.Location = new System.Drawing.Point(471, 20);
            this.cmbCycle.Name = "cmbCycle";
            this.cmbCycle.Size = new System.Drawing.Size(121, 27);
            this.cmbCycle.TabIndex = 3;
            // 
            // nextpic
            // 
            this.nextpic.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.nextpic.Cursor = System.Windows.Forms.Cursors.Hand;
            this.nextpic.Image = ((System.Drawing.Image)(resources.GetObject("nextpic.Image")));
            this.nextpic.Location = new System.Drawing.Point(384, 9);
            this.nextpic.Name = "nextpic";
            this.nextpic.Size = new System.Drawing.Size(46, 51);
            this.nextpic.TabIndex = 2;
            this.nextpic.TabStop = false;
            this.nextpic.Click += new System.EventHandler(this.nextpic_Click);
            // 
            // prevpic
            // 
            this.prevpic.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.prevpic.Cursor = System.Windows.Forms.Cursors.Hand;
            this.prevpic.Image = ((System.Drawing.Image)(resources.GetObject("prevpic.Image")));
            this.prevpic.Location = new System.Drawing.Point(236, 9);
            this.prevpic.Name = "prevpic";
            this.prevpic.Size = new System.Drawing.Size(49, 51);
            this.prevpic.TabIndex = 1;
            this.prevpic.TabStop = false;
            this.prevpic.Click += new System.EventHandler(this.prevpic_Click);
            // 
            // play_pause
            // 
            this.play_pause.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.play_pause.Cursor = System.Windows.Forms.Cursors.Hand;
            this.play_pause.Image = ((System.Drawing.Image)(resources.GetObject("play_pause.Image")));
            this.play_pause.Location = new System.Drawing.Point(310, 9);
            this.play_pause.Name = "play_pause";
            this.play_pause.Size = new System.Drawing.Size(49, 51);
            this.play_pause.TabIndex = 0;
            this.play_pause.TabStop = false;
            this.play_pause.Click += new System.EventHandler(this.play_pause_Click);
            // 
            // trackBar
            // 
            this.trackBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.trackBar.Location = new System.Drawing.Point(0, 0);
            this.trackBar.Name = "trackBar";
            this.trackBar.Size = new System.Drawing.Size(819, 45);
            this.trackBar.TabIndex = 14;
            this.trackBar.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBar.Scroll += new System.EventHandler(this.trackBar_Scroll);
            this.trackBar.MouseMove += new System.Windows.Forms.MouseEventHandler(this.trackBar_MouseMove);
            // 
            // PanTop
            // 
            this.PanTop.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PanTop.Controls.Add(this.cmbSkin);
            this.PanTop.Controls.Add(this.cmbSource);
            this.PanTop.Controls.Add(this.cmbType);
            this.PanTop.Controls.Add(this.btnSearch);
            this.PanTop.Controls.Add(this.txtKeyWord);
            this.PanTop.Controls.Add(this.btnPlay);
            this.PanTop.Location = new System.Drawing.Point(12, 0);
            this.PanTop.Name = "PanTop";
            this.PanTop.Size = new System.Drawing.Size(813, 44);
            this.PanTop.TabIndex = 17;
            // 
            // cmbSkin
            // 
            this.cmbSkin.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSkin.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmbSkin.FormattingEnabled = true;
            this.cmbSkin.Location = new System.Drawing.Point(603, 8);
            this.cmbSkin.Name = "cmbSkin";
            this.cmbSkin.Size = new System.Drawing.Size(121, 24);
            this.cmbSkin.TabIndex = 16;
            this.cmbSkin.SelectedIndexChanged += new System.EventHandler(this.cmbSkin_SelectedIndexChanged);
            // 
            // cmbSource
            // 
            this.cmbSource.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSource.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmbSource.FormattingEnabled = true;
            this.cmbSource.Location = new System.Drawing.Point(10, 13);
            this.cmbSource.Name = "cmbSource";
            this.cmbSource.Size = new System.Drawing.Size(84, 24);
            this.cmbSource.TabIndex = 21;
            this.cmbSource.SelectedIndexChanged += new System.EventHandler(this.cmbSource_SelectedIndexChanged);
            // 
            // cmbType
            // 
            this.cmbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbType.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmbType.FormattingEnabled = true;
            this.cmbType.Location = new System.Drawing.Point(100, 13);
            this.cmbType.Name = "cmbType";
            this.cmbType.Size = new System.Drawing.Size(143, 24);
            this.cmbType.TabIndex = 20;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(456, 10);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 19;
            this.btnSearch.Text = "搜索";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtKeyWord
            // 
            this.txtKeyWord.Location = new System.Drawing.Point(330, 12);
            this.txtKeyWord.Name = "txtKeyWord";
            this.txtKeyWord.Size = new System.Drawing.Size(100, 21);
            this.txtKeyWord.TabIndex = 18;
            // 
            // btnPlay
            // 
            this.btnPlay.Location = new System.Drawing.Point(247, 12);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(75, 23);
            this.btnPlay.TabIndex = 17;
            this.btnPlay.Text = "播放";
            this.btnPlay.UseVisualStyleBackColor = true;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // PanLeft
            // 
            this.PanLeft.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PanLeft.Controls.Add(this.lvwData);
            this.PanLeft.Location = new System.Drawing.Point(12, 50);
            this.PanLeft.Name = "PanLeft";
            this.PanLeft.Size = new System.Drawing.Size(559, 311);
            this.PanLeft.TabIndex = 18;
            // 
            // lvwData
            // 
            this.lvwData.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.lvwData.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            SongIndex,
            this.SongName,
            this.Songer});
            this.lvwData.ContextMenuStrip = this.DownFile;
            this.lvwData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvwData.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lvwData.FullRowSelect = true;
            this.lvwData.GridLines = true;
            this.lvwData.Location = new System.Drawing.Point(0, 0);
            this.lvwData.MultiSelect = false;
            this.lvwData.Name = "lvwData";
            this.lvwData.Size = new System.Drawing.Size(559, 311);
            this.lvwData.TabIndex = 11;
            this.lvwData.UseCompatibleStateImageBehavior = false;
            this.lvwData.View = System.Windows.Forms.View.Details;
            this.lvwData.DoubleClick += new System.EventHandler(this.lvwData_DoubleClick);
            this.lvwData.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lvwData_MouseMove);
            // 
            // SongName
            // 
            this.SongName.Text = "歌曲";
            this.SongName.Width = 250;
            // 
            // Songer
            // 
            this.Songer.Text = "歌手";
            this.Songer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Songer.Width = 180;
            // 
            // PanRight
            // 
            this.PanRight.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PanRight.Controls.Add(this.lvwLyric);
            this.PanRight.Location = new System.Drawing.Point(501, 50);
            this.PanRight.Name = "PanRight";
            this.PanRight.Size = new System.Drawing.Size(329, 311);
            this.PanRight.TabIndex = 19;
            // 
            // lvwLyric
            // 
            this.lvwLyric.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            歌词});
            this.lvwLyric.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvwLyric.Location = new System.Drawing.Point(0, 0);
            this.lvwLyric.Name = "lvwLyric";
            this.lvwLyric.Size = new System.Drawing.Size(329, 311);
            this.lvwLyric.TabIndex = 11;
            this.lvwLyric.UseCompatibleStateImageBehavior = false;
            this.lvwLyric.View = System.Windows.Forms.View.Details;
            this.lvwLyric.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lvwLyric_MouseMove);
            // 
            // 歌词
            // 
            歌词.Text = "歌词";
            歌词.Width = 325;
            // 
            // FrmNewMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(837, 466);
            this.Controls.Add(this.PanRight);
            this.Controls.Add(this.PanLeft);
            this.Controls.Add(this.PanTop);
            this.Controls.Add(this.PanButtom);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FrmNewMain";
            this.Text = "FrmNewMain";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmNewMain_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FrmNewMain_FormClosed);
            this.Load += new System.EventHandler(this.FrmNewMain_Load);
            this.SizeChanged += new System.EventHandler(this.FrmNewMain_SizeChanged);
            this.DownFile.ResumeLayout(false);
            this.PanButtom.ResumeLayout(false);
            this.PanButtom.PerformLayout();
            this.panelButtom.ResumeLayout(false);
            this.panelButtom.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UpVoice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nextpic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prevpic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.play_pause)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar)).EndInit();
            this.PanTop.ResumeLayout(false);
            this.PanTop.PerformLayout();
            this.PanLeft.ResumeLayout(false);
            this.PanRight.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private Sunisoft.IrisSkin.SkinEngine skinEngine1;
        private System.Windows.Forms.ContextMenuStrip DownFile;
        private System.Windows.Forms.ToolStripMenuItem DownFileTool;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Panel PanButtom;
        private System.Windows.Forms.Panel panelButtom;
        private System.Windows.Forms.NumericUpDown UpVoice;
        public System.Windows.Forms.Label lblSongName;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label lblCurrent;
        public System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.ComboBox cmbCycle;
        private System.Windows.Forms.PictureBox nextpic;
        private System.Windows.Forms.PictureBox prevpic;
        private System.Windows.Forms.PictureBox play_pause;
        public System.Windows.Forms.TrackBar trackBar;
        private System.Windows.Forms.Panel PanTop;
        private System.Windows.Forms.ComboBox cmbSkin;
        private System.Windows.Forms.ComboBox cmbSource;
        private System.Windows.Forms.ComboBox cmbType;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtKeyWord;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Panel PanLeft;
        public System.Windows.Forms.ListView lvwData;
        private System.Windows.Forms.ColumnHeader SongName;
        private System.Windows.Forms.ColumnHeader Songer;
        private System.Windows.Forms.Panel PanRight;
        public System.Windows.Forms.NotifyIcon notifyIcon1;
        public ListViewDoubleBuffer lvwLyric;
    }
}